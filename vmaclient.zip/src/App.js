import React from 'react';
 
import Router from './routers';
 

function App() {
  return (
    <Router />
  );
}

export default App;
